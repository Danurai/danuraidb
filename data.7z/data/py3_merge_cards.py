# Merge ringsdb and cgdb

import json, shutil

def main():
	cgdb=json.loads(open('data\cgdb_data.json','r',encoding='utf-8').read())
	ringsdb=json.loads(open('data\\ringsdbraw\\ringsdb-api-public-cards.json','r').read())

	lotrdbextra=json.loads(open('data\data_extra.json','r',encoding='utf-8').read())
	lotrdb_nightmare=lotrdbextra['nightmare']
	lotrdb_update=lotrdbextra['update']
	lotrdb_add=lotrdbextra['add']
	
	# fix cgdb cards hardcoded and lotrdbupdate
	# update cgdb with data from ringsdb
	# add cards from lotrdbextra
	# save and copy file
	
	for c in ringsdb:
		if int(c['code'][-5:][2:]) != c['position']:
			print(f'RingsDB issue {c["code"]} <> {c["position"]}')
	#prune ringsdb
	ring_keys = ['code','imagesrc','octgnid','url','name','text','traits','illustrator','has_errata']
	ringsdb = list(map(lambda x: {k: x[k] for k in ring_keys if k in x },ringsdb))
	
	ringsmap={}
	for c in ringsdb:
		ringsmap[c['code']]=c

	# Fix CGDB cards
	for c in cgdb:
		if c["name"]=="Wrapped!" and c["code"]=="04076": # Wrapped and Hama are both card 76 in the Dwarrowdelf cycle
			c["code"] = "04076a"
		if c['code'] in lotrdb_nightmare:
			c.update(lotrdb_nightmare[c['code']])
		if c["code"] in lotrdb_update:
			c.update(lotrdb_update[c['code']])
		if c['code']=='146064': del c['victory']
		if c['code'] in ringsmap:
			c.update(ringsmap[c['code']])

	for k, v in lotrdb_add.items():
		cgdb.append(v)

	cgdb.sort(key=lambda x: x['code'])
	print(f'Writing {len(cgdb)} cards')
	with open('data/lotrdb_data_cards.json','w',encoding='utf-8') as f:
		json.dump(cgdb,f,indent=2,ensure_ascii=False,sort_keys=True)
		
	#fout='c:/data/projects/danuraidb-main/resources/private/lotrdb/lotrdb_data_cards.json'
	fout='d:/projects/danuraidb/resources/private/lotrdb/lotrdb_data_cards.json'

	shutil.copy2('data/lotrdb_data_cards.json',fout)
	print(f'cgdb_data.json and ringsdb-api-public-cards merged into lotrdb_data_cards.json and copied to {fout}')
		
if __name__ == '__main__':
	main()