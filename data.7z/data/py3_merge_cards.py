# Merge ringsdb and cgdb

import json, shutil

def main():
	cgdb=json.loads(open('cgdb_data.json','r',encoding='utf-8').read())
	ringsdb=json.loads(open('ringsdbraw\\ringsdb-api-public-cards.json','r').read())
	lotrdbextra=json.loads(open('data_extra.json','r',encoding='utf-8').read())
	
	lotrdb_update=lotrdbextra['update']
	lotrdb_add=lotrdbextra['add']
	
	# fix cgdb cards hardcoded and lotrdbupdate
	# update cgdb with data from ringsdb
	# add cards from lotrdbextra
	# save and copy file
	
	#prune ringsdb
	ring_keys = ['code','octgnid','deck_limit','imagesrc','url','text','flavor','illustrator','text','traits','name','has_errata','cost','quantity','type_code','type_name','sphere_code','sphere_name']
	ringsdb = list(map(lambda x: {k: x[k] for k in ring_keys if k in x },ringsdb))
	
	ringsmap={}
	for c in ringsdb:
		ringsmap[c['code']]=c

	# Fix CGDB cards
	for c in cgdb:
		if c["name"]=="Wrapped!" and c["code"]=="04076": # Wrapped and Hama are both card 76 in the Dwarrowdelf cycle
			c["code"] = "04076a"
		#if c["pack_code"]=="OtD" and c["name"]=="Secret Entrance":
		#	c["position"]=45
		#	c["code"]="132045"
		if c["code"] in lotrdb_update:
			c.update(lotrdb_update[c['code']])
			#for t in ["name","quantity","difficulty","encounter_name"]:
			#	if t in lotrdb_update[c["code"]]: c[t]=lotrdb_update[c["code"]][t]
		if c['code'] in ringsmap:
			c.update(ringsmap[c['code']])

	for k, v in lotrdb_add.items():
		cgdb.append(v)
	
	#cgdbcodes=[x['code'] for x in cgdb]
	#for r in ringsdb:
	#	if r['code'] not in cgdbcodes:
	#		if int(r['code'][:2]) < 4:	# LIMIT TO PACKS DEBUG DEBUG TODO
	#			print(f'Adding card {r["code"]} - {r["name"]}')
	#			cgdb.append(r)
	
	cgdb.sort(key=lambda x: x['code'])
	print(f'Writing {len(cgdb)} cards')
	with open('lotrdb_data_cards.json','w',encoding='utf-8') as f:
		json.dump(cgdb,f,indent=2,ensure_ascii=False,sort_keys=True)
		
	#fout='c:/data/projects/danuraidb-main/resources/private/lotrdb_data_cards.json
	fout='d:/projects/danuraidb/resources/private/lotrdb/lotrdb_data_cards.json'

	shutil.copy2('lotrdb_data_cards.json',fout)
	print(f'cgdb_data.json and ringsdb-api-public-cards merged into lotrdb_data_cards.json and copied to {fout}')
		
if __name__ == '__main__':
	main()