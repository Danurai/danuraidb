import json
# 1 check cards 1-X are included in the file
# 2 check pack totals

card_file = 'lotrdb_data_cards.json'

def main():
	cards = json.loads(open(card_file,'r',encoding='utf-8').read())
	
	for c in cards:
		if 'cycle_name' not in c:
			print(c['code'])
	cycles = set([c['cycle_position'] for c in cards])
	cycles = list(cycles)
	
	cycleinfo = {}
	for c in cycles:
		cycards = list(filter(lambda x: x['cycle_position'] == c, cards))
		maxpos = int(max([crd['position'] for crd in cycards]))
		qty    = sum([crd['quantity'] for crd in cycards])
		cycleinfo[c] = {"maxpos": maxpos, "qty": qty}

	for c in cycleinfo:
		for x in range(1,cycleinfo[c]['maxpos']):
			code = format(int(c),'02d')  + format(int(x),'03d')
			card = list(filter(lambda x: x['code'] == code, cards))
			if card == False:
				print(code)

if __name__ == '__main__':
	main()