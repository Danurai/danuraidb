import json, shutil

cgdbfields = ['sku','cards','rulesheet','nightmare','cycle_position']

def main():
	ringsdbpack=json.loads(open('ringsdbraw\\ringsdb-api-public-packs.json','r',encoding='utf-8').read())
	cgdbpack=json.loads(open('bggraw\\bgg_pack_info.json','r',encoding='utf-8').read())
	
	for r in ringsdbpack:
		r['cycle_position']=99
		if r['code'] in cgdbpack:
			cpack = cgdbpack[r['code']]
			r.update({k: cpack[k] for k in cgdbfields})
	
	ringsdbpack=list(filter(lambda x: x['cycle_position'] != 99,ringsdbpack))

	ringsdbpack.sort(key=lambda x: x['cycle_position'])
	json.dump(ringsdbpack,open('lotrdb_data_packs.json','w',encoding='utf-8'),ensure_ascii=False,indent=2)
	
	
	fout='d:/projects/danuraidb/resources/private/lotrdb/lotrdb_data_packs.json'
	shutil.copy2('lotrdb_data_packs.json',fout)
	print(f'lotrdb_data_packs.json updated and copied to {fout}')

if __name__ == '__main__':
	main()