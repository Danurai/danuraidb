import json, os, re

def normalise( str ):
	str = re.sub(u'[\u00e0-\u00e5]','a',str)
	str = re.sub(u'[\u00e8-\u00eb]','e',str)
	str = re.sub(u'[\u00ec-\u00ef]','i',str)
	str = re.sub(u'[\u00f2-\u00f6]','o',str)
	str = re.sub(u'[\u00f9-\u00fc]','u',str)
	return str

def main():

	cards = json.loads(open('data/lotrdb_data_cards.json','r',encoding='utf-8').read())

	encounters = []
	codemap = {}
	for c in cards:
		if 'encounter_name' in c:
			if c['cycle_name'] not in encounters: encounters.append(c['cycle_name'])
			if c['pack_name'] not in encounters: encounters.append(c['pack_name'])
			if c['encounter_name'] not in encounters: encounters.append(c['encounter_name'])

	for e in encounters:
		if e != '':
			edash = normalise(e.lower()).replace('\u0027',' ').replace(' ','-').replace(',','')
			wie=edash.split('-')
			abba = edash if len(wie) == 1 else ''.join([w[0] for w in wie])
			if not abba in codemap:
				codemap[abba]=edash
			else:
				codemap[edash]=edash
	
	#print (codemap)

	p='C:/data/projects/z_resource/lotr/img/set_icons/'
	for c in codemap:
		if 	os.path.exists(p + c + '.png'):
			print(codemap[c])
			os.rename(p + c + '.png',p + 'pack-' + codemap[c] + '.png')

if __name__ == '__main__':
		main()


#magick mogrify -fuzz 50% -fill "transparent" -draw "color 0,0 floodfill" -draw "color 1,1 floodfill" -trim *.png