import re, json, argparse, glob
from operator import itemgetter

# update cgdb_data.json with flavour from selected file in the format r'^cgdb_pretty.+txt$'

def updatecgdbdata(fname):
  f=open(fname,'rb')
  b=f.read()
  d=b.decode('utf8')
  
  d=re.sub(u'\u0301',"'",d)
  
  regex=r'<i>(|.+?)<\/i>.+?<br><b>Set:<\/b>\s(.+?)\s<b>Number:<\/b>\s([0-9]+)'
  g=re.findall(regex,d)
  
  f.close()

  jout=[{"flava":c[0],"set":c[1],"number":int(c[2])} for c in g]
  #jout=sorted(jout, key=itemgetter('number'))
  print (jout)
  with open('cgdb_flava.json','a') as f:
    json.dump(jout,f,indent=2,ensure_ascii=False)
    f.close()
  
  ## Add flava to cgdb_data.json
  with open('cgdb_data_tmp.json','r') as fin:
    cjson=json.loads(fin.read())
    for c in cjson:
      match=list(filter(lambda x: x['number']==c['position'] and x['set']==c['pack_code'], jout))
      if len(match) == 1:
        c['flavor']=match[0]['flava']
    fin.close()
    cjson=sorted(cjson, key=itemgetter('code'))
  
  return cjson
  

outfile="cgdb_data_tmp.json"

def main():
	for fin in glob.glob('cgdb_pretty*txt'):
		print ("Processing " + fin)
		updated = updatecgdbdata (fin)

		with open(outfile,'w') as f:
			json.dump(updated,f,indent=2,ensure_ascii=False)
			f.close()

if __name__ == '__main__':
	main()