import csv, json,re

fieldmap = {
	"pack_name": "set",
	"position": "num",
	"name": "name",
	"is_unique": "unique",
	"type_name": "type",
	"threat": "wt",
	"quest_points": "hp",
	"quantity": "packquantity",
	"deck_limit": "max",
	"encounter_name": "encounter",
	"traits": "trait",
	"text": "text",
	"shadow_text": "shadow",
	"flavor": "flavor",
	"illustrator": "illustrator"
}

nc_template={
	"code": "",
	"set": "",
	"num": "",
	"name": "",
	"unique": "",
	"deck": "",
	"type": "",
	"th": "",
	"wt": "",
	"atk": "",
	"def": "",
	"hp": "",
	"textcost": "",
	"packquantity": "",
	"max": "",
	"sphere": "",
	"encounter": "",
	"trait": "",
	"text": "",
	"shadow": "",
	"flavor": "",
	"illustrator": "",
	"img": "",
	"imgfolder": "",
	"imgsize": "",
	"victory": ""
}

def main():
	fin='data\data_extra.json'
	addcards=json.loads(open(fin,'r',encoding='utf-8').read())['add']
	ldbpacks=json.loads(open('data\lotrdb_data_packs.json','r',encoding='utf-8').read())
	ldbpackmap = dict([[x['name'], x['sku'] ]for x in ldbpacks])

	newcards=[]
	for addcard in addcards:
		ac=addcards[addcard] #list(addcards.values()):
		nc = {}
		nc['code'] = str(addcard)
		for f in fieldmap:
			if f in ac:
				nc[fieldmap[f]] = str(ac[f]).replace('\n','<br>')
		
		if 'cgdbimgurl' in ac:
			res=re.search('.+\/(\w+)\/(.+jpg)$',ac['cgdbimgurl'])
			if res is not None:
				nc['img'] = res[2]
				nc['imgfolder'] = res[1]
				nc['imgsize'] = 'high'
		else:
			#img = (ac['name'] + '-' + ac['pack_name'] + '-' + str(ac['position']) + '.jpg').lower().replace(' ','-')
			#if ac['pack_name']
			img = ldbpackmap[ac['pack_name']] + '_' + str(ac['position']) + '.jpg'
			print(f'Adding art for {addcard} {img}')
			nc['img'] = img
			nc['imgfolder'] = 'lotr'
			nc['imgsize'] = 'high'


		if 'type' in nc:
			if nc['type'] == 'Quest': 
				nc['imgsize'] = 'wide'
				nc['deck'] = 'Quest'
			else:
				nc['deck'] = 'Enemy'
		newcards.append(nc)

	fout='data\data_add.csv'
	with open(fout,'w',newline='',encoding='utf-8') as f:
		w=csv.DictWriter(f, nc_template.keys())
		w.writeheader()
		w.writerows(newcards)

if __name__ == '__main__':
	main()