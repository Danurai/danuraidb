import pyreplaceall
import cgdb_flava_all
import merge_cards

def main():
	pyreplaceall.main()
	cgdb_flava_all.main()
	merge_cards.main()
	
if __name__ == "__main__":
	main()