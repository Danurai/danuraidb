import re, json, glob

cycles = {
  1:  "Core",
  2:  "Shadows of Mirkwood Cycle",
  3:  "Khazad-d\u00fbm",
  4:  "Dwarrowdelf Cycle",
  5:  "Heirs of N\u00famenor",
  6:  "Against The Shadow Cycle",
  7:  "The Voice of Isengard",
  8:  "The Ring-maker Cycle",
  9:  "The Lost Realm",
  10: "Angmar Awakened Cycle",
  11: "The Grey Havens",
  12: "Dream-Chaser Cycle",
  13: "The Hobbit",
  131: "The Hobbit",
  132: "The Hobbit",
  141: "Lord of the Rings Saga Expansions",
  142: "Lord of the Rings Saga Expansions",
  143: "Lord of the Rings Saga Expansions",
  144: "Lord of the Rings Saga Expansions",
  145: "Lord of the Rings Saga Expansions",
  146: "Lord of the Rings Saga Expansions",
  16: "The Sands of Harad",
  17: "Haradrim Cycle",
  18: "The Wilds of Rhovanion",
  19: "Ered Mithril Cycle",
  20: "A Shadow in the East",
  21: "Vengeance of Mordor Cycle",
  99: "Print on Demand"
}

def getint(n):
	res = re.search(r'\d+',n)
	val=0
	if res is not None: 
		val=int(res[0])
	elif n=="-":
		val=0
	elif n=='X':
		val='X'
	return val

def cleantext(t):
	rtn = t.replace(u'U\u0302','[attack]').replace(u'U\u0301','[defense]')
	rtn = re.sub(r'<span style=.+?>(.+?)</span>',r'\1',rtn)
	return rtn

def makecarddict(rawtext,dc):
	crd={}
	crd['cgdbimgurl'] = re.search(r'<img class=\"searchImgCard\" src=\"(.+?)\"',rawtext)[1].replace('tn_','').replace('ffg_','')
	datadict=re.findall(r'<div class=\"searchTextRowLabel.+?>(|.+?)(:</div>|</div>)<div class=\".+?\">(|.+?)</div>',rawtext)
	for c in datadict:
		match c[0]:
			case '':
				name=re.search(r'<a.+?>(.+?)</a>',c[2])[1]
				unique=re.search(r'&nbsp;(.+)',name)
				if unique is None:
					crd['is_unique']=False
					crd['name']=name
				else:
					crd['is_unique'] = True
					crd['name'] = unique[1]
			case 'Type':
				if c[2] == "Side Quest":
					crd['type_code'] =	"player-side-quest"
					crd['type_name'] = "Player Side Quest"
				else:
					crd['type_code'] =	c[2].lower()
					crd['type_name'] = c[2]
			case 'Sphere':
				sphere = c[2].replace('&nbsp;',' ').strip()
				if sphere != "":
					crd['sphere_code'] =	sphere.lower().replace(' ','_')
					crd['sphere_name'] = sphere
			case 'Starting Threat':
				crd['threat'] = getint(c[2])
			case 'Illustrator':
				crd[c[0].lower()] = c[2].strip().replace(u'A\u0301',u'\u00C1')	# Fix for rtailing diacritical A\u0301
			case 'Willpower' | 'Attack' | 'Defense' | 'Quantity' | 'Quest Points' | 'Encounter Info' | "Threat" | "Threat Threshold":
				crd[c[0].lower().replace(' ','_')] = getint(c[2])
			case 'Hit Points':
				crd['health'] = getint(c[2])
			case 'Set':
				crd['pack_name'] = c[2].strip()
			case 'Number':
				crd['position'] = int(c[2])

			case 'Card Text':
				traits=re.search(r'<strong>(.+?)</strong><br>(.+|)',c[2])
				text=""
				if traits is None:
					text = c[2].strip()
				else:
					crd['traits']=traits[1]
					text=traits[2]
				# Fix for [attack] and [defense] replaced by U + \u0301|\u0302 trailing diacriticals - performance not impacted 
				crd['text']=cleantext(text) #.replace(u'U\u0302','[attack]').replace(u'U\u0301','[defense]')
				vp = re.search(r'Victory.+?(\d+)', text)
				if vp is not None:
					crd['victory']=getint(vp[1])

			case 'Shadow Text':
				# Fix for [attack] and [defense] replaced by U + \u0301|\u0302 trailing diacriticals - performance not impacted 
				text = cleantext(c[2])
				if text == "": 
					crd['shadow_text']=None
				else:
					crd['shadow_text']=text
			case 'Encounter':
				if c[2] != "" and c[2] != 'None': crd['encounter_name'] = c[2]
			case 'Victory Points':
				if 'victory' not in crd:
					if c[2]!="" and getint(c[2])!=0: 
						crd['victory']= getint(c[2])
			case _:
				if c[2] == "":
					crd[c[0].lower().replace(' ','_')]=None
				else:
					crd[c[0].lower().replace(' ','_')]=c[2].replace('&nbsp;',' ').strip()
		crd['has_errata']=False
		crd['octgnid']=''
		crd['deck_limit']=3
	packinfo = dc[crd['pack_name']]
	crd['pack_code'] = packinfo['pack_code']
	crd['pack_name'] = packinfo['pack_name']
	crd['cycle_position']=int(packinfo['cycle_id'])
	crd['cycle_name']=cycles[int(packinfo['cycle_id'])]
	number = crd['position']
	# Fix Numbers
	match name:
		case 'Daughter of the Nimrodel': number=58
		case 'Mustering the Rohirrim': number=7
		case 'Dunland Chieftain': number=47
		case 'Take Cover!': number=55
		case 'West Road Traveller': number=121
		case 'Umbar Assassin': number=44
		case 'Scourge of Mordor': number=64
		case 'Stone-Giant': number=64
		case 'Raise the Shire': number=10
	if number == 0: print (f'! Number missing for {crd["name"]}')
	crd['position']=number

	if crd['type_code'] == 'player_side_quest':
		if 'sphere_code' not in crd:
			crd['sphere_code'] =	"neutral"
			crd['sphere_name'] = "Neutral"

	crd['code'] = format(int(packinfo['cycle_id']),'02d')  + format(number,'03d')
	
	if 'flavor' in crd: del crd['flavor']
	return crd

def createcards(fname):
	
	fin=open('data_cycles.json','r',encoding='utf-8')
	dc=json.loads(fin.read())
	fin.close

	cards = []
	with open(fname,'r',encoding='utf8') as f:
		b=f.read()
		g=re.findall('<li class="searchLiCard">(.+?)</li>',b)
		for c in g:
			crd=makecarddict(c,dc)
			cards.append(crd)
	return cards

def main():
	jj=[]
	fl=[f for f in glob.glob('cgdbraw/*.txt') if re.search(r'cgdbraw\\[0-9].+txt$',f)]
	print (f'Reading files {fl}')
	for fname in fl:
		print(f'Reading {fname}')
		cards=createcards(fname)
		print(f'Writing {len(cards)} records from {fname}')
		jj=jj+cards 

	print(f'Writing {len(jj)} records to json' )
	jj.sort(key=lambda x: x['code'])
	with open('cgdb_data.json','w',encoding='utf-8') as f:
		json.dump(jj,f,indent=2,ensure_ascii=False,sort_keys=True)

if __name__ == '__main__':
	main()