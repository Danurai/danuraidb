import shutil

shutil.copy2('lotrdb_data_cards.json.bkp','D:/Projects/danuraidb/resources/private/lotrdb_data_cards.json')
print('cgdb_data.json and ringsdb-api-public-cards merged into lotrdb_data_cards.json and copied')