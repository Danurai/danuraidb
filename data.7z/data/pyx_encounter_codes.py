import json, re, base64, os

# tdr * 3 dc * 3

def main():
	cards = json.loads(open('data/lotrdb_data_cards.json','r',encoding='utf-8').read())
	encounters = []
	for c in cards:
		if 'encounter_name' in c:
			if c['cycle_name'] not in encounters: encounters.append(c['cycle_name'])
			if c['pack_name'] not in encounters: encounters.append(c['pack_name'])
			if c['encounter_name'] not in encounters: encounters.append(c['encounter_name'])

	abba = {}
	for e in encounters:
		oge=e
		if e == 'Core Set': e = 'Core'
		e=re.sub(u'[\u2019|\u0027|\u201A\u002d]',' ',e)
		if e != '':
			words_in_e = list(re.findall('\w+',e))
			code = (''.join([w[0] for w in words_in_e]) if len(words_in_e) > 1 else e).lower()
			print (e,code)
			imguri=None
			imgpath = 'c:/data/projects/z_resource/lotr/img/set_icons/{}.png'.format(code.lower())
			if os.path.exists(imgpath): imguri = 'data:image/png;base64,{}'.format(base64.b64encode(open(imgpath,'rb').read()).decode('ascii'))

			abba[oge]={'code': code.lower(),'imguri':imguri}

	json.dump(abba,open('data/data_uris.json','w',encoding='utf-8'),indent=2,ensure_ascii=False)
if __name__ == '__main__':
	main()

