import json, shutil

cgdbfields = ['sku','cards','rulesheet','nightmare']

def main():
	ringsdbpack=json.loads(open('ringsdbraw\\ringsdb-api-public-packs.json','r',encoding='utf-8').read())
	cgdbpack=json.loads(open('bggraw\\bgg_pack_info.json','r',encoding='utf-8').read())
	
	for r in ringsdbpack:
		if r['code'] in cgdbpack:
			cpack = cgdbpack[r['code']]
			r.update({k: cpack[k] for k in cgdbfields})
	
	json.dump(ringsdbpack,open('lotrdb_data_packs.json','w',encoding='utf-8'),ensure_ascii=False,indent=2)
	
	shutil.copy2('lotrdb_data_packs.json','c:/data/projects/danuraidb-main/resources/private/lotrdb_data_packs.json')
	print('lotrdb_data_packs.json updated and copied to danuraidb/private/resources')

if __name__ == '__main__':
	main()