import py1_cgdbtojson
import py2_flava
import py3_merge_cards

def main():
	py1_cgdbtojson.main()
	py2_flava.main()
	py3_merge_cards.main()
	
if __name__ == "__main__":
	main()