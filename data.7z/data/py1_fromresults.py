import json, re
import html

#cgdbimgurl="http://www.cardgamedb.com/forums/uploads/{{folder}}//{{file}}.jpg"

src="data\\cgdbraw\\cgdb_results.json"
tgt="data\\cgdb_data.json"
cycles = {1:  "Core", 2:  "Shadows of Mirkwood Cycle", 3:  "Khazad-d\u00fbm", 4:  "Dwarrowdelf Cycle", 5:  "Heirs of N\u00famenor", 6:  "Against The Shadow Cycle", 7:  "The Voice of Isengard", 8:  "The Ring-maker Cycle", 9:  "The Lost Realm", 10: "Angmar Awakened Cycle", 11: "The Grey Havens", 12: "Dream-Chaser Cycle", 13: "The Hobbit", 131: "The Hobbit", 132: "The Hobbit", 141: "Lord of the Rings Saga Expansions", 142: "Lord of the Rings Saga Expansions", 143: "Lord of the Rings Saga Expansions", 144: "Lord of the Rings Saga Expansions", 145: "Lord of the Rings Saga Expansions", 146: "Lord of the Rings Saga Expansions", 16: "The Sands of Harad", 17: "Haradrim Cycle", 18: "The Wilds of Rhovanion", 19: "Ered Mithril Cycle", 20: "A Shadow in the East", 21: "Vengeance of Mordor Cycle", 99: "Print on Demand"}

# 1 convert cgdbresults.json to lotrdb_data_cards
#   - generate Code
#		- convert Unicode to utf-8
# 2 fix card numbers, quantities etc (is_unique), add difficulty ratings
# 3 add cgdb_flava
# 4 copy file

def getint(n):
	res = re.search(r'\d+',str(n))
	val=0
	if res is not None: 
		val=int(res[0])
	elif n=="-":
		val=0
	elif n!="":
		val=n
	return val

def getval(key, card, *args, **kwargs):
	if key in card:
		if (v := card[key]) is not None:
			castint = kwargs.get('int', False)
			if castint:
				return getint(v)
			else:
				return v
		else:
			return None
	else: 
		return None

def cleantext(t):
	rtn = html.unescape(t)
	rtn = rtn.replace(u'U\u0302','[attack]').replace(u'U\u0301','[defense]').replace('<br />','<br>')
	rtn = re.sub(r'<span\s+style=.+?>(.+?)</span>',r'\1',rtn, flags=re.IGNORECASE)
	rtn = re.sub('<br/>|<BR>|\\r','<br>',rtn)
	return rtn

def main():
	cgdbjson=json.loads(open(src,'r',encoding='utf-8').read())
	ringsdb_cards=[]
	missing_sets = []

	dp=json.loads(open('data\data_packs.json','r',encoding='utf-8').read())
	
	for card in cgdbjson:
		rdbc={}
		match (card['name']):
			case 'Battering Ram': card['type'] = 'Enemy'
			case 'Morgul Spider': card['type'] = 'Enemy'
			case 'Dru-buri-Dru':  card['type'] = 'Enemy' 
			case 'Send for Aid':  card['type'] = "Side Quest"
			case 'Goblins are Upon You!': card['type'] = 'Treachery'
			case 'No Way Out':       card['set'] = "TDT"
			case 'Rivendell Scout':  card['set'] = "TTT"
			case 'Vanguard of Bolg': card['set'] = "OtD"
			case 'Hallowed Circle':  card['encounter'] = "The Three Trials"
			case 'Lord Alcaron':     card['deck'] = "Encounter"
			case 'Wind from the Sea': card['sphere'] = 'Neutral'
			
		set = card['set']
		if card['num'] == "00-":	  # Missing Number
			print(f'Number 00- {card["set"]}\{card["name"]}')
		elif set not in dp: # Missing Cycle in dp
			if set not in missing_sets:
				missing_sets.append(set)
				print(f'Unknown Set {set}-{card["name"]}')
		else:												# Transform Card
			attack  = getval('atk',card,int=True)
			defense = getval('def',card,int=True)
			wt      = getval('wt',card,int=True)
			hp_qp   = getval('hp',card,int=True)
			cost 		= str(getval('textcost',card,int=True))
			th      = getval('th', card,int=True)
			encounter = getval('encounter',card)
			sphere  = getval('sphere',card)
			trait   = card['trait']
			type		= card['type']
			
			rdbc['type_name'] = type
			rdbc['type_code'] = type.lower().replace(' ','-')

			rdbc['deck_limit']			= card['max']

			match (type):
				case 'Hero' | 'Ally':
					if card['type'] != 'Hero': 
						rdbc['cost'] = cost
					else: 
						rdbc['threat']  = th
					rdbc['willpower'] = wt
					rdbc['attack']  = attack
					rdbc['defense'] = defense
					rdbc['health']  = hp_qp
					rdbc['sphere_name']=sphere
					rdbc['sphere_code']=sphere.lower()
				case 'Event' | 'Attachment':
					rdbc['cost']=cost
					rdbc['sphere_name']=sphere
					rdbc['sphere_code']=sphere.lower()
				case 'Enemy':
					rdbc['threat']  = wt
					rdbc['attack']  = attack
					rdbc['defense'] = defense
					rdbc['health']  = hp_qp
					rdbc['threat_threshold'] = th
					rdbc['deck_limit']		 = 0
				case 'Objective' | 'Objective Ally':
					rdbc['encounter_name'] = encounter
					rdbc['deck_limit']		 = 0
					if attack is not None:
						rdbc['willpower'] = wt
						rdbc['attack']  = attack
						rdbc['defense'] = defense
						rdbc['health']  = hp_qp
					else:
						rdbc['threat'] = wt
				case 'Location' | 'Objective-Location':
					rdbc['threat'] = wt
					rdbc['quest_points']  = hp_qp
					rdbc['deck_limit']		 = 0
				case 'Quest': 
					rdbc['encounter_name'] = encounter
					rdbc['quest_points']  = hp_qp
				case 'Side Quest':
					rdbc['cost']=cost
					rdbc['quest_points']  = hp_qp
					rdbc['sphere_name']=sphere
					rdbc['sphere_code']=sphere.lower()
					if card['deck'] == 'Hero':
						rdbc['type_name'] = 'Player Side Quest'
						rdbc['type_code'] = 'player-side-quest'
				case 'Treasure':
					rdbc['cost']=cost 
					rdbc['encounter_name'] = encounter
				case 'Campaign':
					rdbc['encounter_name'] = encounter

			if card['deck'] == 'Encounter':
				rdbc['encounter_name'] = encounter
				if card['shadow'] != "": 
					rdbc['shadow_text'] = cleantext(card['shadow'])
				else: 
					rdbc['shadow_text'] = None
					
			if (v := getval('victory',card)) is not None: 
				if v!="":
					if v.isnumeric():
						rdbc['victory']=int(v)
					else:
						rdbc['victory']=v
			
			if trait != "": rdbc['traits'] = trait
			rdbc['name'] 						= card['name'] 
			rdbc['is_unique']   		= card['unique']=="Yes"
			rdbc['text']						= cleantext(card['text'])
			rdbc['illustrator'] 		= card['illustrator'].strip().replace(u'A\u0301',u'\u00C1')	# Fix for tailing diacritical A\u0301
			rdbc['cgdbimgurl'] 			= f'http://www.cardgamedb.com/forums/uploads/{card["imgfolder"]}/{card["img"]}'
			rdbc['has_errata']			= False
			rdbc['octgnid']					= ''
			if 'victory' not in rdbc:
				vp = re.search(r'Victory.+?(\d+)', rdbc['text'])
				if vp is not None:
					rdbc['victory']=getint(vp[1])
			limit = re.search('Limit (\d) per deck',rdbc['text'])
			if limit is not None:
				rdbc['deck_limit'] = int(limit[1])

			#dependant on pack_code
			packinfo = dp[set]
			rdbc['pack_code'] 			= packinfo['pack_code']
			rdbc['pack_name'] 			= packinfo['pack_name']
			cyc_pos = int(packinfo['cycle_id'])
			rdbc['cycle_position']	= int(cyc_pos / 10) if cyc_pos in [131,132,141,142,143,144,145,146] else cyc_pos
			rdbc['cycle_name']			= cycles[cyc_pos]

			number=int(card['num'])
			match rdbc['name']:
				case 'Daughter of the Nimrodel': number=58
				case 'Mustering the Rohirrim': number=7
				case 'Dunland Chieftain': number=47
				case 'Take Cover!': number=55
				case 'West Road Traveller': number=121
				case 'Umbar Assassin': number=44
				case 'Scourge of Mordor': number=64
				case 'Stone-Giant': number=64
				case 'Raise the Shire': number=10
				case 'Secret Entrance': number=45 
			if number == 0: print (f'! Number missing for {rdbc["name"]}')
			rdbc['position'] 	= number
			rdbc['code'] 			= format(int(packinfo['cycle_id']),'02d')  + format(number,'03d')
			if card['packquantity'] == "":
				#print(f'missing qty {rdbc["code"]}')
				rdbc['quantity'] = 3
			else:	
				rdbc['quantity']  			= getval('packquantity',card,int=True)
			
			ringsdb_cards.append(rdbc)
	
	ringsdb_cards.sort(key=lambda x: x['code'])
	with open(tgt,'w',encoding='utf-8') as fout:
		json.dump(ringsdb_cards,fout,indent=2,ensure_ascii=False,sort_keys=True)

if __name__ == '__main__':
	main()

#src_types=['Ally', 'Attachment', 'burden treachery', 'Campaign', 'Contract', 'Enemy', 'Event', 'Hero', 'Location', 'Objective', 'Objective Ally', 'Objective-Location', 'Quest', 'Side Quest', 'Treachery', 'Treasure']
#src_keys=['___id', '___s', 'atk', 'banned', 'cost', 'deck', 'def', 'difficulty', 'encounter', 'encounterlist', 'flavor', 'fullurl', 'furl', 'guid', 'hp', 'id', 'illustrator', 'img', 'imgfolder', 'imgsize', 'label', 'max', 'name', 'num', 'packquantity', 'rabbr', 'rating', 'sequence', 'set', 'setid', 'setname', 'shadow', 'sphere', 'text', 'textcost', 'th', 'trait', 'type', 'unique', 'victory', 'wt']

## unmapped ##
# 'deck' - {'Hero', 'Quest', 'Encounter'}
# 'banned' - {None}
# 'difficulty' - ['', 0, 1, None]
# 'imgsize' - {'high', 'wide'}
# 'encounterlist'

## mapped ##
# 'atk'
# 'cost'
# 'def'
# 'encounter'
# 'hp'
# 'illustrator'
# 'img'
# 'imgfolder'
# 'max'
# 'name'
# 'num'
# 'packquantity'
# 'set'
# 'shadow'
# 'sphere'
# 'text'
# 'textcost'
# 'th'
# 'trait'
# 'type'
# 'unique'
# 'victory'
# 'wt'

## cardgamedb refs ##
# 'fullurl'
# 'furl' 
# 'guid' {'', 'narvis-belt-kd', None}
# 'id'
# 'label' ~ 'name'
# 'rabbr' {''}
# 'rating' {'2', '5', '0', '3', '4', '1'}
# 'sequence' {'', '13,14', '5A', '3A', '1C', '15,16', '25-27', '5-8', '0', '18', '11,12', '16,17', '-', '2C', '29,30', '17', '1A', '2A', '6', '3', '4C', '11', '20', '9', '13', '4A', '2', '19,20', '24', '25,26', '5', '8', '3C', '21,22', '9,10', '11-15', '23,24', '1', '18-20', '17,18', '7', '27,28', '27', '4', '10'}
# 'setid' (recalculated)
# 'setname' (recalculated)
# '___id'
# '___s'
# 'flavor' {None}