import json, re
import html

#cgdbimgurl="http://www.cardgamedb.com/forums/uploads/{{folder}}//{{file}}.jpg"

src="cgdbraw\\cgdb_results.json"
tgt="cgdb_data.json"
cycles = {1:  "Core", 2:  "Shadows of Mirkwood Cycle", 3:  "Khazad-d\u00fbm", 4:  "Dwarrowdelf Cycle", 5:  "Heirs of N\u00famenor", 6:  "Against The Shadow Cycle", 7:  "The Voice of Isengard", 8:  "The Ring-maker Cycle", 9:  "The Lost Realm", 10: "Angmar Awakened Cycle", 11: "The Grey Havens", 12: "Dream-Chaser Cycle", 13: "The Hobbit", 131: "The Hobbit", 132: "The Hobbit", 141: "Lord of the Rings Saga Expansions", 142: "Lord of the Rings Saga Expansions", 143: "Lord of the Rings Saga Expansions", 144: "Lord of the Rings Saga Expansions", 145: "Lord of the Rings Saga Expansions", 146: "Lord of the Rings Saga Expansions", 16: "The Sands of Harad", 17: "Haradrim Cycle", 18: "The Wilds of Rhovanion", 19: "Ered Mithril Cycle", 20: "A Shadow in the East", 21: "Vengeance of Mordor Cycle", 99: "Print on Demand"}

# 1 convert cgdbresults.json to lotrdb_data_cards
#   - generate Code
#		- convert Unicode to utf-8
# 2 fix card numbers, quantities etc (is_unique), add difficulty ratings
# 3 add cgdb_flava
# 4 copy file

def getint(n):
	res = re.search(r'\d+',str(n))
	val=0
	if res is not None: 
		val=int(res[0])
	elif n=="-":
		val=0
	elif n!="":
		val=n
	return val

def getval(key, card, *args, **kwargs):
	if key in card:
		if (v := card[key]) is not None:
			castint = kwargs.get('int', False)
			if castint:
				return getint(v)
			else:
				return v
		else:
			return None
	else: 
		return None

def cleantext(t):
	rtn = html.unescape(t)
	rtn = rtn.replace(u'U\u0302','[attack]').replace(u'U\u0301','[defense]').replace('<br />','<br>')
	rtn = re.sub(r'<span\s+style=.+?>(.+?)</span>',r'\1',rtn, flags=re.IGNORECASE)
	rtn = re.sub('<br/>|<BR>|\\r','<br>',rtn)
	return rtn

def main():
	cgdbjson=json.loads(open(src,'r',encoding='utf-8').read())
	ringsdb_cards=[]
	missing_sets = []

	dc=json.loads(open('data_cycles.json','r',encoding='utf-8').read())
	
	for card in cgdbjson:
		rdbc={}
		match (card['name']):
			case 'Battering Ram': card['type'] = 'Enemy'
			case 'Morgul Spider': card['type'] = 'Enemy'
			case 'Dru-buri-Dru':  card['type'] = 'Enemy' 
			case 'Send for Aid':  card['type'] = "Side Quest"
			case 'No Way Out':       card['set'] = "TDT"
			case 'Rivendell Scout':  card['set'] = "TTT"
			case 'Vanguard of Bolg': card['set'] = "OtD"
			case 'Hallowed Circle':  card['encounter'] = "The Three Trials"
			case 'Lord Alcaron':     card['deck'] = "Encounter"
			
		set = card['set']
		if card['num'] == "00-":	  # Missing Number
			print(f'Number 00- {card["set"]}\{card["name"]}')
		elif set not in dc: # Missing Cycle in dc
			if set not in missing_sets:
				missing_sets.append(set)
				print(f'Unknown Set {set}-{card["name"]}')
			a=1
		else:												# Transform Card
			attack  = getval('atk',card,int=True)
			defense = getval('def',card,int=True)
			wt      = getval('wt',card,int=True)
			hp_qp   = getval('hp',card,int=True)
			cost 		= str(getval('cost',card))
			th      = getval('th', card,int=True)
			encounter = getval('encounter',card)
			sphere  = getval('sphere',card)
			trait   = card['trait']

			#+ getval('textcost',card)
			match (card['type']):
				case 'Hero' | 'Ally':
					if card['type'] != 'Hero': 
						rdbc['cost'] = cost
					else: 
						rdbc['threat']  = th
					rdbc['willpower'] = wt
					rdbc['attack']  = attack
					rdbc['defense'] = defense
					rdbc['health']  = hp_qp
					rdbc['sphere_name']=sphere
					rdbc['sphere_code']=sphere.lower()
				case 'Event' | 'Attachment':
					rdbc['cost']=cost
					rdbc['sphere_name']=sphere
					rdbc['sphere_code']=sphere.lower()
				case 'Side Quest':
					#rdbc['sphere_name']=sphere
					#rdbc['sphere_code']=sphere.lower()
					rdbc['quest_points']  = hp_qp
				case 'Enemy':
					rdbc['threat']  = wt
					rdbc['attack']  = attack
					rdbc['defense'] = defense
					rdbc['health']  = hp_qp
					rdbc['threat_threshold'] = th
				case 'Objective' | 'Objective Ally':
					rdbc['encounter_name'] = encounter
					if attack is not None:
						rdbc['willpower'] = wt
						rdbc['attack']  = attack
						rdbc['defense'] = defense
						rdbc['health']  = hp_qp
					else:
						rdbc['threat'] = wt
				case 'Location' | 'Objective-Location':
					rdbc['threat'] = wt
					rdbc['quest_points']  = hp_qp
				case 'Quest': 
					rdbc['encounter_name'] = encounter
					rdbc['quest_points']  = hp_qp
				case 'Treasure' | 'Campaign':
					rdbc['encounter_name'] = encounter


			if (v := getval('type',card, int=False)) is not None:
				rdbc['type_name']=v
				rdbc['type_code']=v.lower().replace(' ','-')

			if card['deck'] == 'Encounter':
				rdbc['encounter_name'] = encounter
				if card['shadow'] != "": 
					rdbc['shadow_text'] = cleantext(card['shadow'])
				else: 
					rdbc['shadow_text'] = None
					
			if (v := getval('max', card,int=True)) is not None: rdbc['deck_limit']=3 #TODO V
			if (v := getval('victory',card)) is not None: 
				if v!="":
					if v.isnumeric():
						rdbc['victory']=int(v)
					else:
						rdbc['victory']=v
			
			if trait != "": rdbc['traits'] = trait
			rdbc['name'] 						= card['name'] 
			rdbc['is_unique']   		= card['unique']=="Yes"
			rdbc['text']						= cleantext(card['text'])
			rdbc['illustrator'] 		= card['illustrator'].strip().replace(u'A\u0301',u'\u00C1')	# Fix for rtailing diacritical A\u0301
			rdbc['cgdbimgurl'] 			= f'http://www.cardgamedb.com/forums/uploads/{card["imgfolder"]}/{card["img"]}'
			rdbc['quantity']  			= getval('packquantity',card,int=True)
			rdbc['has_errata']			= False
			rdbc['octgnid']					= ''
			if 'victory' not in rdbc:
				vp = re.search(r'Victory.+?(\d+)', rdbc['text'])
				if vp is not None:
					rdbc['victory']=getint(vp[1])

			#dependant on pack_code
			packinfo = dc[set]
			rdbc['pack_code'] 			= packinfo['pack_code']
			rdbc['pack_name'] 			= packinfo['pack_name']
			rdbc['cycle_position']	= int(packinfo['cycle_id'])
			rdbc['cycle_name']			= cycles[int(packinfo['cycle_id'])]

			number=int(card['num'])
			match rdbc['name']:
				case 'Daughter of the Nimrodel': number=58
				case 'Mustering the Rohirrim': number=7
				case 'Dunland Chieftain': number=47
				case 'Take Cover!': number=55
				case 'West Road Traveller': number=121
				case 'Umbar Assassin': number=44
				case 'Scourge of Mordor': number=64
				case 'Stone-Giant': number=64
				case 'Raise the Shire': number=10
				case 'Secret Entrance': number=45 
			if number == 0: print (f'! Number missing for {rdbc["name"]}')
			rdbc['position'] 	= number
			rdbc['code'] 			= format(int(packinfo['cycle_id']),'02d')  + format(number,'03d')
			
			ringsdb_cards.append(rdbc)
	
	ringsdb_cards.sort(key=lambda x: x['code'])
	with open(tgt,'w',encoding='utf-8') as fout:
		json.dump(ringsdb_cards,fout,indent=2,ensure_ascii=False,sort_keys=True)
	#	
	#	if (v := getval(card['max'])) is not None: rdbc['deck_limit']=v
	#		#	case 'difficulty': data_extra
	#			case 'encounter_name':'encounter',
	#		#	case 'flavor':'flavor'
	#		#	case 'has_errata': ringsdb.has_errata
	#			case 'illustrator':'illustrator',
	#		#	case 'imagesrc':ringsdb.imgsrc
	#			case 'is_unique':'unique',
	#		#	case 'octgnid':ringsdb.octgnid
	#		#	case 'pack_code':(generate)
	#			case 'pack_name':'set',
	#			case 'quantity':'packquantity',
	#			case 'shadow_text':'shadow',
	#			case 'sphere_code':'sphere',
	#			case 'sphere_name':'sphere',
	#			case 'text':'text',
	#			case 'threat_threshold':'th',
	#			case 'traits':'trait',
	#			case 'type_code':'type',
	#			case 'type_name':'type',
	#		#	case 'url': ringsdb.url
	#			case 'victory':'victory',
	#			case 'willpower':'wt'

if __name__ == '__main__':
	main()

#key_list = {
#	'attack': 		'atk',
#	'cgdbimgurl': ['img''imgfolder''imgsize'],
##	'code': (generate),
#	'cost':'cost' or 'textcost',
#	'cycle_name':'setname',
##	'cycle_position':(generate)
#	'deck_limit':'max',
#	'defense':'def',
##	'difficulty': data_extra
#	'encounter_name':'encounter',
##	'flavor':'flavor'
##	'has_errata': ringsdb.has_errata
#	'health':'hp',
#	'illustrator':'illustrator',
##	'imagesrc':ringsdb.imgsrc
#	'is_unique':'unique',
#	'name':'name',
##	'octgnid':ringsdb.octgnid
##	'pack_code':(generate)
#	'pack_name':'set',
#	'position':'num',
#	'quantity':'packquantity',
#	'quest_points':'hp',
#	'shadow_text':'shadow',
#	'sphere_code':'sphere',
#	'sphere_name':'sphere',
#	'text':'text',
#	'threat':'wt' or 'th',
#	'threat_threshold':'th',
#	'traits':'trait',
#	'type_code':'type',
#	'type_name':'type',
##	'url': ringsdb.url
#	'victory':'victory',
#	'willpower':'wt'
#}
#	
#
# Add These?
#'rabbr':
#'rating': Card Rating
#'sequence': Scenario Sequence
#'banned':			'banned',
#'deck': Encounter, Quest etc
#'imgsize'

# Extra
# 'difficulty': encounter difficulty?
# 'encounterlist': list of decks in encounter
#'fullurl' lowercase, no spaces or special characters
#'furl':
#'guid':
#'id':
#'label': normalised name
#'setid':


#rdbkeys = ['attack', 'cgdbimgurl', 'code', 'cost', 'cycle_name', 'cycle_position', 'deck_limit', 'defense', 'difficulty', 'encounter_name', 'flavor', 'has_errata', 'health', 'illustrator', 'imagesrc', 'is_unique', 'name', 'octgnid', 'pack_code', 'pack_name', 'position', 'quantity', 'quest_points', 'shadow_text', 'sphere_code', 'sphere_name', 'text', 'threat', 'threat_threshold', 'traits', 'type_code', 'type_name', 'url', 'victory', 'willpower']
#types=['Ally', 'Attachment', 'burden treachery', 'Campaign', 'Contract', 'Enemy', 'Event', 'Hero', 'Location', 'Objective', 'Objective Ally', 'Objective-Location', 'Quest', 'Side Quest', 'Treachery', 'Treasure']
