# Merge ringsdb and cgdb

import json, shutil

def main():
	cgdb=json.loads(open('cgdb_data.json','r',encoding='utf-8').read())
	ringsdb=json.loads(open('ringsdbraw\\ringsdb-api-public-cards.json','r').read())
	lotrdbextra=json.loads(open('lotrdb_extra_data.json','r',encoding='utf-8').read())
	
	lotrdb_update=lotrdbextra['update']
	lotrdb_add=lotrdbextra['add']
	
	# start with cgdb
	# fix cards
	# Add info frmo ringsdb
	# update info from lotrdbextra
	# save and copy file
	
	ringsmap={}
	for c in ringsdb:
		ringsmap[c['code']]=c

	for c in cgdb:
		if c["name"]=="Wrapped!" and c["code"]=="04076": # Wrapped and Hama are both card 76 in the Dwarrowdelf cycle
			c["code"] = "04076a"
		if c["name"]=="Umbar Assassin" and c["code"]=="05041": # Local Trouble and Umbar Assassin in Heirs of Numenor
			c["code"] = "05041a"
		if c["pack_code"]=="OtD" and c["name"]=="Secret Entrance":
			c["position"]=45
			c["code"]="132045"
		if c["code"] in ["05031","05049"]:
			del c["sphere_name"]
			del c["sphere_code"]
		if c["code"] in lotrdb_update:
			for t in ["name","quantity","difficulty","encounter_name"]:
				if t in lotrdb_update[c["code"]]: c[t]=lotrdb_update[c["code"]][t]
		if not c["code"] in ringsmap:
			ringsdb.append(c)
		else:
			for x in ringsdb:
				if x['code'] == c['code']:
					x=c.update(x)
		
	
	for k, v in lotrdb_add.items():
		ringsdb.append(v)
	
	ringsdb.sort(key=lambda x: x['code'])
	with open('lotrdb_data_cards.json','w') as f:
		json.dump(ringsdb,f,indent=2,sort_keys=True)
		
		
	shutil.copy2('lotrdb_data_cards.json','D:/Projects/danuraidb/resources/private/lotrdb_data_cards.json')
	print('cgdb_data.json and ringsdb-api-public-cards merged into lotrdb_data_cards.json and copied')
		
if __name__ == '__main__':
	main()