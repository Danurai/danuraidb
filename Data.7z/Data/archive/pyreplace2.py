import re
import argparse

if __name__ == '__main__':
#================================
# Parse Command Line Args
#================================
	parser = argparse.ArgumentParser()
	parser.add_argument('-f','--filename', help='Enter source filename.')
	args = parser.parse_args()
	
	filein = args.filename 
	fileout = re.sub(r'(.+?).txt',r'\1_out.txt',filein)

	fin = open(filein,"r")
	fout = open(fileout,"w")

	for line in fin:
		line=re.sub(r'<ul id="searchUL">(.+?)</ul>',r'\1',line.rstrip()) 			# Remove <ul> tags
		
		line=re.sub(r'<li>.+?</li>','',line)								# Remove Cards Returned, rating, search, comments
		line=re.sub(r'<li style=.+?</li>','',line)
		line=re.sub(r'<div class="rating">.+?</div>','',line)
		line=re.sub(r'<div class="search">.+?</div>','',line)
		line=re.sub(r'<div class="deckcount">.+?</div>','',line)
		line=re.sub(r'<div class="cardComments">(.+?)</div>','',line)
		line=re.sub('<div class="clear"></div>','',line)
		
		# Update Name: line
		line=re.sub('<div class="searchTextRowLabel"></div>','<div class="searchTextRowLabel">Name:</div>',line)
		line=re.sub(r'<h1.+?<a.+?>(.+?)</a>.+?</h1>',r'\1',line)
		
		# add newline for each <li> after the first and Remove <li> tags
		line=re.sub(r'(.)<li',r'\1\n<li',line)
		line=re.sub(r'<li class="searchLiCard">(.+?)</li>',r'\1',line)

		# Create Art: line
		line=re.sub(r'<div class="searchDivImage">.+?src="(.+?)".+?</div>',r'Art:\t\1',line)

		#put returns in for data lines
		line=re.sub('<div class="searchTextRowLabel','\n<div class="searchTextRowLabel',line)
		
		# Convert Data lines
		line=re.sub(r'<div class="searchTextRowLabel.+?>(.+?)</div>',r'\1',line)
		line=re.sub(r'<div class="searchTextContent.+?>(.+?|)</div>',r'\t\1',line)
		
		#cleanup
		line=re.sub('<div class="searchDivCard">','',line)
		line=re.sub('<div class="searchText">','',line)
		line=re.sub('<i>null&nbsp;</i>','',line)
		line=re.sub('</div></div>','',line)
		line=re.sub('strong>','b>',line)
		line=re.sub(r'nbsp\n;',r'\n',line)
		line=re.sub('&nbsp;',' ',line)
		line=re.sub(r' \t',r'\t',line)
		line=re.sub('<div class="searchText ">','',line)
		
		# Remove Span tags
		line=re.sub(r'<span.+?>(.+?)</span>',r'\1',line)
		
		
		fout.write(line)
		
	fin.close()
	fout.close()