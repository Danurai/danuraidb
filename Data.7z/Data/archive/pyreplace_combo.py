import glob, re, os, json, sys

# Does a pyreplace2 -f <file> for all files in the directory with the format ^[0-9].+txt$ e.g. 1_core_heq.txt

def convertfile(filein):

	fin = open(filein,"r")

	for line in fin:
		line=re.sub(r'<ul id="searchUL">(.+?)</ul>',r'\1',line.rstrip()) 			# Remove <ul> tags
		
		line=re.sub(r'<li>.+?</li>','',line)								# Remove Cards Returned, rating, search, comments
		line=re.sub(r'<li style=.+?</li>','',line)
		line=re.sub(r'<div class="rating">.+?</div>','',line)
		line=re.sub(r'<div class="search">.+?</div>','',line)
		line=re.sub(r'<div class="deckcount">.+?</div>','',line)
		line=re.sub(r'<div class="cardComments">(.+?)</div>','',line)
		line=re.sub('<div class="clear"></div>','',line)
		
		# Update Name: line
		line=re.sub('<div class="searchTextRowLabel"></div>','<div class="searchTextRowLabel">Name:</div>',line)
		line=re.sub(r'<h1.+?<a.+?>(.+?)</a>.+?</h1>',r'\1',line)
		
		# add newline for each <li> after the first and Remove <li> tags
		line=re.sub(r'(.)<li',r'\1\n<li',line)
		line=re.sub(r'<li class="searchLiCard">(.+?)</li>',r'\1',line)

		# Create Art: line
		line=re.sub(r'<div class="searchDivImage">.+?src="(.+?)".+?</div>',r'Art:\t\1',line)

		#put returns in for data lines
		line=re.sub('<div class="searchTextRowLabel','\n<div class="searchTextRowLabel',line)
		
		# Convert Data lines
		line=re.sub(r'<div class="searchTextRowLabel.+?>(.+?)</div>',r'\1',line)
		line=re.sub(r'<div class="searchTextContent.+?>(.+?|)</div>',r'\t\1',line)
		
		#cleanup
		line=re.sub('<div class="searchDivCard">','',line)
		line=re.sub('<div class="searchText">','',line)
		line=re.sub('<i>null&nbsp;</i>','',line)
		line=re.sub('</div></div>','',line)
		line=re.sub('strong>','b>',line)
		line=re.sub(r'nbsp\n;',r'\n',line)
		line=re.sub('&nbsp;',' ',line)
		line=re.sub(r' \t',r'\t',line)
		line=re.sub('<div class="searchText ">','',line)
		
		# Remove Span tags
		line=re.sub(r'<span.+?>(.+?)</span>',r'\1',line)
		
		
	fin.close()
	return line


def main():
	#clean
	for f in glob.glob('*out.txt'):
		os.remove(f)
		
	jj=[]
	fl=[f for f in glob.glob('*.txt') if re.search(r'^[0-9].+txt$',f)]
	for f in fl:
		print ("converting: " + f)
		jin=convertfile(f)
		jj=jj+jin
	
	with open('cgdb_data.json','w') as f:
		json.dump(jj,f,indent=2,ensure_ascii=False)
		
	print('cgdb_data.json saved')
		
if __name__ == '__main__':
	main()

	