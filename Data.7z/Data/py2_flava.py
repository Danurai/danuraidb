import glob, re, json

def createcards(fname):
	fin=open('data_cycles.json','r',encoding='utf-8')
	dc=json.loads(fin.read())
	fin.close

	with open(fname,'r',encoding='utf-8') as f:
		d=f.read()
		cards = {}
		g=re.findall(r'<tr>(.+?)</tr>',d)
		for c in g:
			flava=re.search(r'<i>(|.+?)</i>',c)
			if flava is not None:
				name=re.search(r'<a.+?>(|.+?)</a>',c)[1]
				#print (f'Reading {name}')
				set = re.search(r'<b>Set:</b>\s(.+?)\s<b>',c)[1]
				numres = re.search(r'<b>Number:</b>\s(\d{1,})',c)
				if numres is None: 
					print (f'! Number missing for {fname} - {name}')
					match name:
						case 'Dunland Chieftain': number='47'
						case 'Take Cover!': number='55'
						case _: number = 0
				else:
					number = numres[1]
				if set in dc: 
					cycle_id=dc[set]['cycle_id']
					code=cycle_id.rjust(2,'0') + number.rjust(3,'0')
					cards[code] = flava[1]
				else: 
					print(f'! Set Key Error: {fname} {name} {set}')
					
	f.close()
	return cards
			
def main():
	jj={}
	fl=[f for f in glob.glob('cgdbraw/*.txt') if re.search(r'cgdbraw\\cgdb_pretty_.+txt$',f)]
	print (f'Reading files {fl}')
	for fname in fl:
		print(f'Reading {fname}')
		cards=createcards(fname)
		print(f'Writing {len(cards)} records from {fname}')
		jj.update(cards) 

	print(f'Writing {len(jj)} records to json' )
	with open('cgdb_flava.json','w',encoding='utf-8') as f:
		json.dump(jj,f,indent=2,ensure_ascii=False,sort_keys=True)


	cgdbdata=json.loads(open('cgdb_data.json','r',encoding='utf-8').read())
	for card in cgdbdata:
		if card['code'] in jj:
			card['flavor'] = jj[card['code']]
	json.dump(cgdbdata,open('cgdb_data.json','w',encoding='utf-8'),indent=2,ensure_ascii=False)
	print('Flavor added to cgdb_data.json')


if __name__ == '__main__':
	main()