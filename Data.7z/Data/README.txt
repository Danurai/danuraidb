Process
=======
1. Generate cgdb data file cgdb_data.json

1.1 Extract html from http://www.cardgamedb.com/index.php/lotr/lord-of-the-rings-card-spoiler SEARCH
    and save in the format ^[0-9].+txt$ e.g. 102_lotr_tbr.txt$
1.2 Run py1_cgdbtojson.py to consolidate ^[0-9].+txt$ files to cgdb_data.json

2. Add flavour Text

2.1 Extract html from http://www.cardgamedb.com
    e.g. http://www.cardgamedb.com/index.php/lotr/lord-of-the-rings-card-spoiler/_/core/
    and save in the format ^cgdb_pretty.+txt$
2.2 Run py2_flava.py to add ^cgdb_pretty.+txt$ flavour text to cgdb_data.json

3. Merge Cards

3.1 Ensure you also have files 
	  cgdb_data.json (Steps 1 and 2)
	  ringsdb-api-public-cards.json (Download from ringsdb.com)
    lotrdb_extra_data.json (Update Data and Add Cards)
3.2 Run py3_merge_cards.py to create lotrdb_data_cards.json and 'C:/data/projects/lotrdb/resources/private/lotrdb_data_cards.json'



Card Fixes

find: "name":\s(.+)\[defense](.+)
replace: "name": $1\\u00fa$2

find: "name":\s(.+)\[attack](.+)
replace: "name": $1\\u00fb$2

Anduril 
  "name": "And[defense]ril"
  "142014": {"name": "And\u00faril"}

Rumil
  "name": "R[defense]mil"
  "08028": {"name": "R\u00famil"}

Munuv Duv Ravine
  "name": "Munuv D[attack]v Ravine"
  "08015": {"name": "Munuv D\u00fbv Ravine"}
  
Counts
x core 226
x kd 165
x +360
x hon 165
x +360
x voi 156
x +360
o tlr 165
o +360
o tgh 165
o +360
o soh 156
o +360
o wor 156
o +360
o sie ?156
o +360

Saga
x ohauh 165
x otd 165
x tbr 165
x trd 165
x ttos 165
o tlos 165
o tfotw 165
o tmof 165

144015
