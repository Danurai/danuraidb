import glob, re, os, json, sys

sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir))
import pyreplace2

# Does a pyreplace2 -f <file> for all files in the directory with the format ^[0-9].+txt$ e.g. 1_core_heq.txt

def main():
	#clean
	for f in glob.glob('*out.txt'):
		os.remove(f)
		
	jj=[]
	fl=[f for f in glob.glob('*.txt') if re.search(r'^[0-9].+txt$',f)]
	for f in fl:
		print ("converting: " + f)
		jin=pyreplace2.convertfile(f)
		jj=jj+jin
	
	with open('cgdb_data.json','w') as f:
		json.dump(jj,f,indent=2,ensure_ascii=False)
		
	print('cgdb_data.json saved')
		
if __name__ == '__main__':
	main()