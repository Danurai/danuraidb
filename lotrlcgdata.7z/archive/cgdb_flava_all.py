import cgdb_flava_v1, glob, json

outfile="cgdb_data.json"

def main():
	for fin in glob.glob('cgdb_pretty*txt'):
		print ("Processing " + fin)
		updated = cgdb_flava_v1.updatecgdbdata (fin)

		with open(outfile,'w') as f:
			json.dump(updated,f,indent=2,ensure_ascii=False)
			f.close()

if __name__ == '__main__':
	main()