import json, glob, re

def getint(n):
	res = re.search(r'\d+',n.strip())
	val=0
	if res is not None: 
		val=int(res[0])
	elif n=='X':
		val='X'
	return val

def getcards(fname):	
	fin=open('data_cycles.json','r',encoding='utf-8')
	dc=json.loads(fin.read())
	fin.close
	cards = {}
	with open(fname,'r',encoding='utf-8') as f:
		d=f.read()
		g=re.findall(r'<tr>(.+?)</tr>',d)
		for c in g:
			crd = {}
			name=re.search(r'<a.+?>(|.+?)</a>',c)
			if name is not None:
				set = re.search(r'<b>Set:</b>\s(.+?)\s<b>',c)
				numres = re.search(r'<b>Number:</b>\s(\d{1,})',c)		
				if numres is None: 
					print (f'! Number missing for {fname} - {name[1]}')
					match name[1]:
						case 'Dunland Chieftain': number='47'
						case 'Take Cover!': number='55'
						case _: number = 0
				else:
					number = numres[1]

				if set is not None:
					if set[1] in dc: 
						cycle_id=str(dc[set[1]]['cycle_id'])
						code=cycle_id.rjust(2,'0') + number.rjust(3,'0')
						crd['code'] = code
						crd['name'] = name[1]
						crd['number'] = number
						img = re.search(r'<img src=\"(.+?)\"',c)
						if img is not None: crd['cgdbimgurl'] = "http://www.cardgamedb.com" + img[1] 
						crd.update(dc[set[1]])
						del crd['cycle_id']
						ot = re.findall(r'<b>(.+?)(:</b>|</b>:)(.+?)<',c)
						for c in ot:
							(k, x, v) = list(map(lambda x: x.strip(),c))
							match k:
								case 'Set':
									n=x
								case 'Type':
									crd['type_code'] =	v.lower()
									crd['type_name'] = v
								case 'Sphere':
									crd['sphere_code'] =	v.lower()
									crd['sphere_name'] = v
								case 'Starting Threat':
									crd['threat'] = getint(v)
								case 'Illustrator':
									crd[k.lower()] = v
								case 'Willpower' | 'Attack' | 'Defense' | 'Quantity' | 'Quest Points' | 'Cost' | 'Encounter Info' | "Threat" | "Threat Threshold":
									crd[k.replace(r' ','_').lower()] = getint(v)
								case 'Hit Points':
									crd['health'] = getint(v)
								case 'Encounter Set':
									crd['encounter_name'] = v
								#case _:
							#		crd['text'] = '<b>' + k + v
						cards[code] = crd
					else: 
						print(f'! Set Key Error: {fname} {name} {set}')
	f.close()
	return cards

def main():
	cards = {}
	fl=[f for f in glob.glob('cgdbraw/*.txt') if re.search(r'cgdbraw\\cgdb_pretty.+txt$',f)]
	print (f'Reading files {fl}')
	for fname in fl:
		print(f'Reading {fname}')
		cards.update(getcards(fname))
	print(f'Writing {len(cards)} cards')
	with open('cgdb_flava_data.json','w',encoding='utf-8') as f:
		json.dump(cards,f,indent=2,ensure_ascii=False,sort_keys=True)

if __name__ == "__main__":
	main()