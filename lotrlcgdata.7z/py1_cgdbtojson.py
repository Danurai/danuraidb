import re, json, glob


def getint(n):
	res = re.search(r'\d+',n)
	val=0
	if res is not None: 
		val=int(res[0])
	elif n=='X':
		val='X'
	return val

def createcards(fname):
	
	fin=open('data_cycles.json','r',encoding='utf-8')
	dc=json.loads(fin.read())
	fin.close

	cards = []
	with open(fname,'r',encoding='utf8') as f:
		b=f.read()
		g=re.findall('<li class="searchLiCard">(.+?)</li>',b)
		for c in g:
			crd={}
			crd['cgdbimgurl'] = re.search(r'<img class=\"searchImgCard\" src=\"(.+?)\"',c)[1]
			datadict=re.findall(r'<div class=\"searchTextRowLabel\">(|.+?)(:</div>|</div>)<div class=\".+?\">(|.+?)</div>',c)
			for c in datadict:
				match c[0]:
					case '':
						name=re.search(r'<a.+?>(.+?)</a>',c[2])[1]
						unique=re.search(r'&nbsp;(.+)',name)
						if unique is None:
							crd['is_unique']=False
							crd['name']=name
						else:
							crd['is_unique'] = True
							crd['name'] = unique[1]
						#print(f'Reading {fname + crd["name"]}')
					case 'Type':
						crd['type_code'] =	c[2].lower()
						crd['type_name'] = c[2]
					case 'Sphere':
						crd['sphere_code'] =	c[2].lower()
						crd['sphere_name'] = c[2]
					case 'Starting Threat':
						crd['threat'] = getint(c[2])
					case 'Illustrator':
						crd[c[0].lower()] = c[2].strip()
					case 'Willpower' | 'Attack' | 'Defense' | 'Quantity' | 'Quest Points' | 'Cost' | 'Encounter Info' | "Threat" | "Threat Threshold":
						crd[c[0].lower().replace(' ','_')] = getint(c[2])
					case 'Hit Points':
						crd['health'] = getint(c[2])
					case 'Set':
						crd['pack_name'] = c[2]
					case 'Number':
						crd['position'] = int(c[2])
					case 'Card Text':
						traits=re.search(r'<strong>(.+?)</strong><br>(.+)',c[2])
						if traits is None:
							crd['text'] = c[2].strip()
						else:
							crd['traits']=traits[1]
							crd['text']=traits[2]
					case 'Encounter':
						crd['encounter_name'] = c[2]
					case _:
						crd[c[0]]=c[2].strip()
				crd['has_errata']=False
				crd['octgnid']=''
				crd['flavor']=''
				crd['deck_limit']=3
			packinfo = dc[crd['pack_name']]
			crd['pack_code'] = packinfo['pack_code']
			number = crd['position']
			if number == 0:
					print (f'! Number missing for {fname} - {crd["name"]}')
					match name:
						case 'Dunland Chieftain': number=47
						case 'Take Cover!': number=55
						case _: number = 0
			crd['code'] = format(int(packinfo['cycle_id']),'02d')  + format(number,'03d')
			crd['flavor'] = ''
			cards.append(crd)
	return cards

def main():
	jj=[]
	fl=[f for f in glob.glob('cgdbraw/*.txt') if re.search(r'cgdbraw\\[0-9].+txt$',f)]
	print (f'Reading files {fl}')
	for fname in fl:
		print(f'Reading {fname}')
		cards=createcards(fname)
		print(f'Writing {len(cards)} records from {fname}')
		jj=jj+cards 

	print(f'Writing {len(jj)} records to json' )
	jj.sort(key=lambda x: x['code'])
	with open('cgdb_data.json','w',encoding='utf-8') as f:
		json.dump(jj,f,indent=2,ensure_ascii=False)

if __name__ == '__main__':
	main()